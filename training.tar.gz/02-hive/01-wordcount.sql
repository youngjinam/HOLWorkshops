beeline -u jdbc:hive2://util1.hadoop.com:10000/user08 -n user08 -p

!q
!sh clear

create external table wordcount (
line string
)
location '/user/user08/wordcount/input';

show tables;

select explode(split(line,'\\s')) as word from wordcount;

select word, count(word) as cnt
from (
select explode(split(line,'\\s')) as word from wordcount
) a
group by word
order by word;


alter table wordcount set serdeproperties ('serialization.encoding'='MS949');

select word, count(word) as cnt
from (
select explode(split(line,'\\s')) as word from wordcount
) a
group by word
order by word;

drop table wordcount;

create external table wordcount (
line string
)
row format serde "org.apache.hadoop.hive.serde2.lazy.LazySimpleSerDe"
with serdeproperties ('serialization.encoding'='MS949')
location '/user/user08/wordcount/input';

#with serdeproperties ('serialization.encoding'='MS949','field.delim'='\t')
