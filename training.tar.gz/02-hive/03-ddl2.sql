beeline -u jdbc:hive2://util1.hadoop.com:10000/user08 -n user08 -p

!q
!sh clear

!sh hdfs dfs -mkdir products users weblogs

!sh hdfs dfs -ls 

!sh hdfs dfs -put -f products.tsv products
!sh hdfs dfs -put -f users.tsv users
!sh hdfs dfs -put -f weblogs.tsv weblogs



create external table products (
url string,
category string
)
row format delimited fields terminated by '\t'
stored as textfile
location '/user/user08/products'
tblproperties ('skip.header.line.count'='1');


create external table users (
swid string,
birth_dt string,
gender_cd string
)
row format delimited fields terminated by '\t'
stored as textfile
location '/user/user08/users'
tblproperties ('skip.header.line.count'='1');


create external table weblogs (
col_1 string, col_2 string, col_3 string, col_4 string, col_5 string,
col_6 string, col_7 string, col_8 string, col_9 string, col_10 string,
col_11 string, col_12 string, col_13 string, col_14 string, col_15 string,
col_16 string, col_17 string, col_18 string, col_19 string, col_20 string,
col_21 string, col_22 string, col_23 string, col_24 string, col_25 string,
col_26 string, col_27 string, col_28 string, col_29 string, col_30 string,
col_31 string, col_32 string, col_33 string, col_34 string, col_35 string,
col_36 string, col_37 string, col_38 string, col_39 string, col_40 string,
col_41 string, col_42 string, col_43 string, col_44 string, col_45 string,
col_46 string, col_47 string, col_48 string, col_49 string, col_50 string,
col_51 string, col_52 string, col_53 string
)
row format delimited fields terminated by '\t'
stored as textfile
location '/user/user08/weblogs';


show tables;


create table weblog as
select
col_2 ts,
col_8 ip,
col_13 url,
col_14 swid,
col_50 city,
col_51 country,
col_53 state
from weblogs;


create table weblog_an
row format delimited fields terminated by ','
stored as textfile
as
select
to_date(o.ts) logdate,
o.url,
o.ip,
o.city,
upper(o.state) state,
o.country,
p.category,
cast(datediff(from_unixtime(unix_timestamp()), from_unixtime(unix_timestamp(u.birth_dt,'yyyy-MM-dd'))) / 365 as int) age,
u.gender_cd
from weblog o
     join products p
       on o.url = p.url
left join users u
       on o.swid = concat('{', u.swid, '}');



!sh hdfs dfs -count -v -h hive/weblog_an


drop table weblog_an purge;

create table weblog_an
stored as parquet
as
select
to_date(o.ts) logdate,
o.url,
o.ip,
o.city,
upper(o.state) state,
o.country,
p.category,
cast(datediff(from_unixtime(unix_timestamp()), from_unixtime(unix_timestamp(u.birth_dt,'yyyy-MM-dd'))) / 365 as int) age,
u.gender_cd
from weblog o
     join products p
       on o.url = p.url
left join users u
       on o.swid = concat('{', u.swid, '}');


!sh hdfs dfs -count -v -h hive/weblog_an


create table accesslog (
ts string,
ip string,
url string,
swid string,
city string,
country string,
state string
)
partitioned by (dt string)
stored as parquet;


insert into accesslog partition (dt)
select
col_2 ts,
col_8 ip,
col_13 url,
col_14 swid,
col_50 city,
col_51 country,
col_53 state,
substr(col_2,1,10) dt
from weblogs;


select dt, count(1) cnt
from accesslog
group by dt
order by dt;


!sh hdfs dfs -ls hive/accesslog

!sh hdfs dfs -ls hive/accesslog/dt=2012-03-01


alter table accesslog drop partition(dt='2012-03-01');


!sh hdfs dfs -ls hive/accesslog


insert into accesslog partition(dt)
select
col_2 ts,
col_8 ip,
col_13 url,
col_14 swid,
col_50 city,
col_51 country,
col_53 state,
substr(col_2,1,10) dt
from weblogs
where col_2 like '2012-03-01%';


!sh hdfs dfs -ls hive/accesslog

!sh hdfs dfs -ls hive/accesslog/dt=2012-03-01



insert overwrite table accesslog partition(dt)
select
col_2 ts,
col_8 ip,
col_13 url,
col_14 swid,
col_50 city,
col_51 country,
col_53 state,
substr(col_2,1,10) dt
from weblogs
where col_2 like '2012-03-01%';


select count(1) from accesslog where dt='2012-03-01';

