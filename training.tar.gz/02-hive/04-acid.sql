/*
Hive ACID Transactions
Atomicity, Consistency, Isolation, Durability
*/

beeline -u jdbc:hive2://util1.hadoop.com:10000/user08 -n user08 -p

!sh clear
!q

create table acid (
key int comment '키',
value int comment '값'
)
comment 'ACID테이블'
clustered by (key) into 3 buckets
stored as orc
tblproperties ('transactional'='true');

describe formatted acid;

show create table acid;


insert into acid values (0,0),(1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),(8,8),(9,9);

select * from acid;


!sh hdfs dfs -ls -R hive/acid


update acid set value=10 where key=0;

delete from acid where key=9;


alter table acid compact 'minor';

alter table acid compact 'major';

