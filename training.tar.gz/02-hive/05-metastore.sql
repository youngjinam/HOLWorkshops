/*
mysql -uhive -p metastore

Enter password: cloudera
*/

show tables;


desc DBS;
desc TBLS;
desc SDS;
desc COLUMNS_V2;
desc TABLE_PARAMS;


select
  a.NAME as DB_NM
, b.TBL_NAME as TBL_NM
, e.PARAM_VALUE as TBL_CMT
, d.COLUMN_NAME as COL_NM
, d.TYPE_NAME as COL_TY
, d.COMMENT as COL_CMT
from DBS a
     join TBLS b
       on b.DB_ID = a.DB_ID
     join SDS c
       on c.SD_ID = b.SD_ID
     join COLUMNS_V2 d
       on d.CD_ID = c.CD_ID
left join TABLE_PARAMS e
       on e.TBL_ID = b.TBL_ID
      and e.PARAM_KEY = 'comment'
where a.NAME = 'user08'
order by a.NAME, b.TBL_NAME, d.INTEGER_IDX;

