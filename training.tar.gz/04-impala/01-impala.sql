impala-shell --help

impala-shell -d user08



show tables;

describe formatted acid;

show create table acid;


/*
ACID R Support
*/
select * from acid;

/*
ACID CUD Not support
*/
insert into acid values (10,10);
update acid set value=99 where key=9;
delete from acid where key=9;


select * from dbs_stag;

select * from dbs_stag order by db_id;


refresh dbs_stag;

invalidate metadata dbs_stag;


create table dbs_lake (
db_id decimal(38,0),
dsc string,
db_location_uri string,
name string,
owner_name string,
owner_type string,
ctlg_name string,
create_time timestamp,
db_managed_location_uri string,
type string,
dataconnector_name string,
remote_dbname string
)
stored as parquet;


insert overwrite table dbs_lake
select
  db_id
, `desc`
, db_location_uri
, name
, owner_name
, owner_type
, ctlg_name
, from_unixtime(create_time)
, db_managed_location_uri
, type
, dataconnector_name
, remote_dbname
from dbs_stag;


select * from dbs_lake;
select * from dbs_lake order by db_id;


describe formatted dbs_lake;


!sh hdfs dfs -count -v -h /user/user08/hive/dbs_lake;
!sh hdfs dfs -count -v -h /user/user08/dbs_stag;

!sh hdfs dfs -ls /user/user08/hive/dbs_lake;
!sh hdfs dfs -ls /user/user08/dbs_stag;

