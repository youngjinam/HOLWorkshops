impala-shell user08


create table kudu_table (
id bigint comment '아이디',
name string comment '이름',
primary key (id)
)
partition by hash partitions 3
comment '쿠두테이블'
stored as kudu;


show create table kudu_table;

describe formatted kudu_table;



insert into kudu_table values (1,'김씨'), (2,'이씨'), (3,'박씨');

select * from kudu_table;

update kudu_table set name='허씨' where id=1;

select * from kudu_table;

upsert into kudu_table values (1,'김씨');

select * from kudu_table;

delete from kudu_table where id=1;


/*
Not support
*/
truncate table kudu_table;

